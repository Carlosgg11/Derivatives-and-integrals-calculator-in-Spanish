/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Formularios;
import org.matheclipse.core.eval.ExprEvaluator;
import org.matheclipse.core.interfaces.IExpr;

/**
 *
 * @author teret
 */
public class Integrador2 {
    
 private final ExprEvaluator util;

    public Integrador2() {
        // Inicializar el evaluador de Symja
        util = new ExprEvaluator();
        //util.setNumericPrecision(10); // Configura la precisión numérica si es necesario
    }

    /**
     * Calcula la integral indefinida de una función simbólica.
     *
     * @param funcion  La función a integrar, como cadena (e.g., "2*x + 5")
     * @param variable La variable de integración (e.g., "x")
     * @return La integral indefinida como cadena
     * @throws Exception Si ocurre un error durante la integración
     */
    public String calcularIntegralIndefinida(String funcion, String variable) throws Exception {
        // Formar la expresión de integración
        String expresion = "Integrate[" + funcion + ", " + variable + "]";

        // Evaluar la expresión
        IExpr resultado = util.evaluate(expresion);

        // Verificar si el resultado es una integral no resuelta
        if (resultado.toString().startsWith("Integrate")) {
            throw new Exception("No se pudo calcular la integral de forma simbólica.");
        }

        // Convertir el resultado a cadena
        return resultado.toString() + " + C"; // Añadir la constante de integración
    }
}
