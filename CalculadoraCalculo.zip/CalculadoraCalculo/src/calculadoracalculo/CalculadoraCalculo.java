/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadoracalculo;
import Formularios.Derivadas;
import Formularios.Menú;
import org.lsmp.djep.djep.DJep;
import org.nfunk.jep.Node;
import org.nfunk.jep.ParseException;

/**
 *
 * @author Jacin
 */
public class CalculadoraCalculo {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Menú M = new Menú();
        M.setVisible(true);
        
    }
}
