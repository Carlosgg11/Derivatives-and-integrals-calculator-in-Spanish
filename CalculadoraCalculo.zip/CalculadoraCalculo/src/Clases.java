/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import org.lsmp.djep.djep.DJep;
import org.nfunk.jep.Node;
import org.nfunk.jep.ParseException;

/**
 * Clase que proporciona funcionalidad para derivar funciones matemáticas.
 * Utiliza la biblioteca DJep para realizar cálculos de derivación.
 */
public class Clases {
    private DJep djep;

    // Constructor de la clase Clases. Inicializa un objeto DJep y configura sus reglas y funciones estándar.
    public Clases() {
        djep = new DJep();
        djep.addStandardFunctions();  // Agrega funciones matemáticas estándar
        djep.addStandardConstants();  // Agrega constantes matemáticas estándar
        djep.addComplex();  // Habilita el manejo de números complejos
        djep.setAllowUndeclared(true);  // Permite el uso de variables no declaradas
        djep.setAllowAssignment(true);  // Permite asignación de valores a variables
        djep.setImplicitMul(true);  // Habilita la multiplicación implícita
        djep.addStandardDiffRules();  // Agrega reglas estándar para la diferenciación
    }

    // Deriva la función especificada con respecto a la variable especificada y devuelve la derivada.
    public String derivar(String funcion, String variable) throws ParseException {
        // Analiza la función proporcionada
        Node nodoFuncion = djep.parse(funcion);
        
        // Realiza la derivación con respecto a la variable especificada
        Node diff = djep.differentiate(nodoFuncion, variable);
        
        // Simplifica la derivada
        Node nodoDerivada = djep.simplify(diff);
        
        // Convierte la derivada en una cadena
        String resultado = djep.toString(nodoDerivada);

        // Elimina ".0" de los números enteros
        resultado = resultado.replaceAll("\\.0\\b", "");

        return resultado;
    }
}