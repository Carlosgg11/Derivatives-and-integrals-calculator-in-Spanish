/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Formularios;

import com.fathzer.soft.javaluator.DoubleEvaluator;
import org.apache.commons.math4.legacy.analysis.UnivariateFunction;
import org.apache.commons.math4.legacy.analysis.integration.SimpsonIntegrator;
import org.apache.commons.math4.legacy.analysis.integration.UnivariateIntegrator;

/**
 * La clase Integrador proporciona funcionalidad para calcular la integral definida de una función matemática.
 */
public class Integrador {
    private final DoubleEvaluator evaluator;

    // Constructor de la clase Integrador
    public Integrador() {
        // Inicializa el evaluador de expresiones Javaluator
        this.evaluator = new DoubleEvaluator();
    }

    // Calcula la integral definida de una función en un intervalo especificado.
    public double calcularIntegralDefinida(String funcion, String variable, double limiteInferior, double limiteSuperior) {
        try {
            // Paso 1: Crear una función univariante a partir de la expresión y la variable de integración
            UnivariateFunction funcionUnivariante = x -> {
                if (variable.equals("x")) {
                    // Si la variable de integración es "x," reemplaza "x" con el valor de x y "y" con 0
                    String expresionConValor = funcion.replaceAll("x", String.valueOf(x)).replaceAll("y", "0");
                    return evaluator.evaluate(expresionConValor);
                } else if (variable.equals("y")) {
                    // Si la variable de integración es "y," reemplaza "y" con el valor de x y "x" con 0
                    String expresionConValor = funcion.replaceAll("y", String.valueOf(x)).replaceAll("x", "0");
                    return evaluator.evaluate(expresionConValor);
                } else {
                    throw new IllegalArgumentException("Variable no válida");
                }
            };

            // Paso 2: Crear un integrador utilizando el método de Simpson
//integrator
        UnivariateIntegrator integrador = new SimpsonIntegrator();

            // Paso 3: Definir los límites de integración
            double a = limiteInferior; // Límite inferior
            double b = limiteSuperior; // Límite superior

            // Paso 4: Calcular la integral definida de la función en el intervalo [a, b]
            double resultado = integrador.integrate(1000, funcionUnivariante, a, b);

            // Paso 5: Devolver el resultado de la integral definida
            return resultado;
        } catch (Exception e) {
            // Manejar cualquier excepción que pueda ocurrir durante el cálculo
            throw new RuntimeException("Error en el cálculo de la integral definida", e);
        }
    }
    
    
}